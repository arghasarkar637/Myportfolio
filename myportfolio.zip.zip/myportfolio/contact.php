<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"] ?? 'Anonymous');
    $email = htmlspecialchars($_POST["email"] ?? 'No email');
    $message = htmlspecialchars($_POST["message"] ?? 'No message');
  } else {
    header("Location: index.php");
    exit();
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Message Sent</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #E0EAFC, #CFDEF3);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }

    .box {
      background: #fff;
      padding: 2.5rem;
      border-radius: 15px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      max-width: 600px;
      width: 90%;
      animation: fadeSlide 1s ease-out forwards;
      transform: translateY(-40px);
      opacity: 0;
      text-align: left;
      z-index: 2;
    }

    @keyframes fadeSlide {
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .box h2 {
      color: #2c3e50;
      margin-bottom: 1rem;
    }

    .info {
      margin-top: 1rem;
      font-size: 1.05rem;
      color: #333;
      line-height: 1.6;
    }

    .info strong {
      color: #007bff;
    }

    .note {
      margin-top: 20px;
      color: #888;
      font-size: 0.9rem;
    }

    .back-btn {
      margin-top: 25px;
      display: inline-block;
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      transition: background-color 0.3s ease;
    }

    .back-btn:hover {
      background-color: #0056b3;
    }

    canvas {
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 1;
    }
  </style>
</head>
<body>

  <canvas id="confetti-canvas"></canvas>

  <div class="box">
    <h2>🎉 Message Sent Successfully!</h2>
    <div class="info">
      <p><strong>Name:</strong> <?= $name ?></p>
      <p><strong>Email:</strong> <?= $email ?></p>
      <p><strong>Message:</strong><br><?= nl2br($message) ?></p>
    </div>
    <p class="note">Thank you for contacting. Stay connected!</p>

    <!-- 🔙 Back to Portfolio Button -->
    <a href="index.php" class="back-btn">← Back to Portfolio</a>
  </div>

  <!-- 🎉 Confetti JS -->
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js"></script>
  <script>
    const duration = 3 * 1000;
    const end = Date.now() + duration;

    (function frame() {
      confetti({
        particleCount: 2,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
      });
      confetti({
        particleCount: 2,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  </script>

</body>
</html>
